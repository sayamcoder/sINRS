package com.spacexstudio.sChatGames.game;

import com.spacexstudio.sChatGames.SChatGames;

/**
 * An abstract blueprint for a chat game.
 * All specific game types (like Unscramble, Type, etc.) will extend this class.
 * It holds the common logic and properties that every game shares.
 */
public abstract class Game {

    protected final SChatGames plugin;
    protected String question;
    protected String answer;
    protected long startTime;

    /**
     * Constructor for a new Game.
     * @param plugin The main instance of the SChatGames plugin.
     */
    public Game(SChatGames plugin) {
        this.plugin = plugin;
    }

    /**
     * Checks if a player's input is the correct answer.
     * This method respects the 'case-sensitive' setting from the config.yml.
     *
     * @param input The player's chat message.
     * @return true if the answer is correct, false otherwise.
     */
    public boolean isCorrect(String input) {
        boolean caseSensitive = plugin.getConfig().getBoolean("settings.case-sensitive");
        if (caseSensitive) {
            return answer.equals(input);
        } else {
            return answer.equalsIgnoreCase(input);
        }
    }

    /**
     * This method should contain the logic for starting the game.
     * This includes generating the question/answer and broadcasting the start message.
     */
    public abstract void start();

    /**
     * This method should contain the logic for ending the game.
     *
     * @param timeout true if the game ended because time ran out, false otherwise.
     */
    public abstract void end(boolean timeout);

    // --- Getters ---

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public long getStartTime() {
        return startTime;
    }
}