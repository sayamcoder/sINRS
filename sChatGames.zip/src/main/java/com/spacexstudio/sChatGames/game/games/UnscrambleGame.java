package com.spacexstudio.sChatGames.game.games;

import com.spacexstudio.sApi.util.ChatUtil;
import com.spacexstudio.sChatGames.SChatGames;
import com.spacexstudio.sChatGames.game.Game;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Represents the "Unscramble" chat game.
 * In this game, players are given a scrambled word and must guess the original.
 */
public class UnscrambleGame extends Game {

    private final List<String> wordList = new ArrayList<>();
    private final Random random = new Random();

    public UnscrambleGame(SChatGames plugin) {
        super(plugin);
        loadWords();
    }

    /**
     * Loads the words for this game from the games.yml config.
     */
    private void loadWords() {
        FileConfiguration gamesConfig = plugin.getConfigManager().getGamesConfig();
        // Get the list of word-list names assigned to this game (e.g., ["medium-words", "hard-words"])
        List<String> listNames = gamesConfig.getStringList("games.UNSCRAMBLE.word-lists");

        // Loop through each assigned list name and add its words to our game's wordList
        for (String listName : listNames) {
            List<String> words = gamesConfig.getStringList("word-lists." + listName);
            wordList.addAll(words);
        }
    }

    @Override
    public void start() {
        // Safety check to ensure we have words to play with.
        if (wordList.isEmpty()) {
            plugin.getLogger().warning("UnscrambleGame has no words to choose from! Check your games.yml configuration.");
            return;
        }

        // 1. Select a random word from our loaded list.
        String originalWord = wordList.get(random.nextInt(wordList.size()));

        // 2. Set the answer to the original word.
        this.answer = originalWord;

        // 3. Scramble the word to create the question.
        this.question = scrambleWord(originalWord);
        // A failsafe: if the scrambled word is somehow the same as the original, re-scramble it.
        // This prevents impossible games like "Cow" being scrambled to "Cow".
        while (this.question.equalsIgnoreCase(this.answer) && this.answer.length() > 2) {
            this.question = scrambleWord(originalWord);
        }

        // 4. Record the start time.
        this.startTime = System.currentTimeMillis();

        // 5. Announce the game to the server.
        Bukkit.broadcastMessage(ChatUtil.colorize("&aA new Chat Game has started!"));
        Bukkit.broadcastMessage(ChatUtil.colorize("&eUnscramble the following word:"));
        Bukkit.broadcastMessage(ChatUtil.colorize("&6&l" + this.question));
    }

    @Override
    public void end(boolean timeout) {
        // No specific logic needed here for now.
    }

    /**
     * A helper method to scramble the letters of a word.
     * @param word The word to scramble.
     * @return The scrambled word.
     */
    private String scrambleWord(String word) {
        // We only scramble words with more than one character.
        if (word.length() <= 1) {
            return word;
        }
        List<String> letters = Arrays.asList(word.split(""));
        Collections.shuffle(letters);
        return String.join("", letters);
    }
}