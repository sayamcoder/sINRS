package com.spacexstudio.sChatGames.game.games;

import com.spacexstudio.sApi.util.ChatUtil;
import com.spacexstudio.sChatGames.SChatGames;
import com.spacexstudio.sChatGames.game.Game;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Represents the "Type" chat game.
 * In this game, a word is presented, and players must type it exactly as shown.
 */
public class TypeGame extends Game {

    private final List<String> wordList = new ArrayList<>();
    private final Random random = new Random();

    public TypeGame(SChatGames plugin) {
        super(plugin);
        loadWords();
    }

    /**
     * Loads the words for this game from the games.yml config.
     */
    private void loadWords() {
        FileConfiguration gamesConfig = plugin.getConfigManager().getGamesConfig();
        // Get the list of word-list names assigned to this game (e.g., ["easy-words", "medium-words"])
        List<String> listNames = gamesConfig.getStringList("games.TYPE.word-lists");

        // Loop through each assigned list name and add its words to our game's wordList
        for (String listName : listNames) {
            List<String> words = gamesConfig.getStringList("word-lists." + listName);
            wordList.addAll(words);
        }
    }

    @Override
    public void start() {
        // Safety check to ensure we have words to play with.
        if (wordList.isEmpty()) {
            plugin.getLogger().warning("TypeGame has no words to choose from! Check your games.yml configuration.");
            // In a more advanced system, we would cancel the game start here.
            // For now, it will just do nothing.
            return;
        }

        // 1. Select a random word from our loaded list.
        String wordToType = wordList.get(random.nextInt(wordList.size()));

        // 2. Set the question and answer. For this game, they are the same.
        this.question = wordToType;
        this.answer = wordToType;

        // 3. Record the start time for calculating the winner's time.
        this.startTime = System.currentTimeMillis();

        // 4. Announce the game to the entire server.
        Bukkit.broadcastMessage(ChatUtil.colorize("&aA new Chat Game has started!"));
        Bukkit.broadcastMessage(ChatUtil.colorize("&eType the following word in chat:"));
        Bukkit.broadcastMessage(ChatUtil.colorize("&6&l" + this.question));
    }

    @Override
    public void end(boolean timeout) {
        // This method is called when the game ends.
        // For the TypeGame, there isn't much to do here besides what the GameManager handles.
    }
}