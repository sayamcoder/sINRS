package com.spacexstudio.sChatGames.manager;

import com.spacexstudio.sChatGames.SChatGames;
import com.spacexstudio.sChatGames.game.Game;
import com.spacexstudio.sChatGames.game.games.TypeGame;
import com.spacexstudio.sChatGames.game.games.UnscrambleGame;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.scheduler.BukkitTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Function;

/**
 * Manages the lifecycle of chat games.
 * This class is responsible for starting, stopping, and keeping track of the currently active game.
 */
public class GameManager {

    private final SChatGames plugin;
    private Game activeGame;
    private BukkitTask timeoutTask;

    private final Random random = new Random();

    // A list of functions that can create new, ENABLED game instances.
    private final List<Function<SChatGames, Game>> enabledGameConstructors = new ArrayList<>();

    public GameManager(SChatGames plugin) {
        this.plugin = plugin;
        this.activeGame = null;

        // Load and register all available game types based on the config.
        registerGameTypes();
    }

    /**
     * Registers all available game types that are marked as 'enabled' in games.yml.
     */
    private void registerGameTypes() {
        FileConfiguration gamesConfig = plugin.getConfigManager().getGamesConfig();

        // Check if the TYPE game is enabled
        if (gamesConfig.getBoolean("games.TYPE.enabled", false)) {
            enabledGameConstructors.add(TypeGame::new);
            plugin.getLogger().info("Game loaded: TYPE");
        }

        // Check if the UNSCRAMBLE game is enabled
        if (gamesConfig.getBoolean("games.UNSCRAMBLE.enabled", false)) {
            enabledGameConstructors.add(UnscrambleGame::new);
            plugin.getLogger().info("Game loaded: UNSCRAMBLE");
        }

        // To add a new game, you would just add another check here.
        // if (gamesConfig.getBoolean("games.MATH.enabled", false)) {
        //     enabledGameConstructors.add(MathGame::new);
        // }
    }

    /**
     * Starts a new, randomly selected and enabled chat game.
     */
    public void startRandomGame() {
        if (isGameActive()) {
            plugin.getLogger().warning("Tried to start a new game while one was already active!");
            return;
        }

        if (enabledGameConstructors.isEmpty()) {
            // This is not an error, it just means no games are enabled in the config.
            return;
        }

        // 1. Pick a random game constructor from our list of ENABLED games.
        Function<SChatGames, Game> randomGameConstructor = enabledGameConstructors.get(random.nextInt(enabledGameConstructors.size()));

        // 2. Use the selected constructor to create a new game instance.
        Game newGame = randomGameConstructor.apply(plugin);

        // 3. Set it as the active game and start it.
        this.activeGame = newGame;
        this.activeGame.start();

        // 4. Schedule a task to run after the time-limit from the config.
        long timeLimitTicks = plugin.getConfig().getLong("settings.time-limit", 30) * 20;

        this.timeoutTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (isGameActive()) {
                SApi.getInstance()
                        .message(plugin.getConfig(), "messages.game-timeout")
                        .with("{answer}", getActiveGame().getAnswer())
                        .send(MessageReceiver.BROADCAST);

                stopCurrentGame(true);
            }
        }, timeLimitTicks);
    }

    /**
     * Stops the currently active game.
     *
     * @param timeout true if the game is being stopped due to a timeout.
     */
    public void stopCurrentGame(boolean timeout) {
        if (!isGameActive()) {
            return;
        }

        if (timeoutTask != null) {
            timeoutTask.cancel();
            timeoutTask = null;
        }

        activeGame.end(timeout);
        this.activeGame = null;
    }

    /**
     * Checks if a chat game is currently in progress.
     * @return true if a game is active, false otherwise.
     */
    public boolean isGameActive() {
        return activeGame != null;
    }

    // --- Getters and Setters ---

    public Game getActiveGame() {
        return activeGame;
    }

    public void setActiveGame(Game game) {
        this.activeGame = game;
    }
}