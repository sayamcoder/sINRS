package com.spacexstudio.sChatGames.manager;

import com.spacexstudio.sChatGames.SChatGames;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

/**
 * Manages all custom configuration files for the plugin.
 */
public class ConfigManager {

    private final SChatGames plugin;
    private FileConfiguration gamesConfig;
    private File gamesFile;

    public ConfigManager(SChatGames plugin) {
        this.plugin = plugin;
        setupConfigs();
    }

    private void setupConfigs() {
        // Create the plugin's data folder if it doesn't exist
        if (!plugin.getDataFolder().exists()) {
            plugin.getDataFolder().mkdir();
        }

        // Setup games.yml
        gamesFile = new File(plugin.getDataFolder(), "games.yml");
        if (!gamesFile.exists()) {
            plugin.saveResource("games.yml", false);
        }
        gamesConfig = YamlConfiguration.loadConfiguration(gamesFile);
    }

    public FileConfiguration getGamesConfig() {
        return gamesConfig;
    }

    public void reloadGamesConfig() {
        if (gamesFile == null) {
            gamesFile = new File(plugin.getDataFolder(), "games.yml");
        }
        gamesConfig = YamlConfiguration.loadConfiguration(gamesFile);
    }
}