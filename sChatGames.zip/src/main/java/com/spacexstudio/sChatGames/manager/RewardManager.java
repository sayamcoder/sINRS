package com.spacexstudio.sChatGames.manager;

import com.spacexstudio.sChatGames.SChatGames;
import org.bukkit.Bukkit;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Manages the distribution of rewards to players who win a chat game.
 */
public class RewardManager {

    private final SChatGames plugin;

    public RewardManager(SChatGames plugin) {
        this.plugin = plugin;
    }

    /**
     * Gives the configured rewards to a winning player.
     *
     * @param winner The player who won the game.
     */
    public void giveRewards(Player winner) {
        // Get the list of reward commands from the config.
        List<String> commands = plugin.getConfig().getStringList("rewards");

        // If there are no commands, do nothing.
        if (commands.isEmpty()) {
            return;
        }

        ConsoleCommandSender console = Bukkit.getServer().getConsoleSender();
        String winnerName = winner.getName();

        plugin.getLogger().info("Giving rewards to " + winnerName + "...");

        // Loop through each command in the list.
        for (String command : commands) {
            // Replace the {player} placeholder with the winner's actual name.
            String commandToExecute = command.replace("{player}", winnerName);

            // Dispatch the command from the console.
            // We run this on the main server thread using the Bukkit scheduler to ensure thread safety.
            Bukkit.getScheduler().runTask(plugin, () -> {
                Bukkit.dispatchCommand(console, commandToExecute);
            });
        }
    }
}