package com.spacexstudio.sChatGames.command;

import com.spacexstudio.sChatGames.SChatGames;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.jetbrains.annotations.NotNull;

public class SChatGamesCommand implements CommandExecutor {

    private final SChatGames plugin;

    public SChatGamesCommand(SChatGames plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 1 && args[0].equalsIgnoreCase("start")) {
            // Permission check
            if (!sender.hasPermission("schatgames.admin.start")) {
                plugin.getMessageManager().sendMessage(sender, "messages.no-permission");
                return true;
            }

            // Check if a game is already running
            if (plugin.getGameManager().isGameActive()) {
                sender.sendMessage("A game is already in progress!"); // We will add this to config later
                return true;
            }

            // Manually start a new game
            plugin.getGameManager().startRandomGame();
            sender.sendMessage("You have manually started a new chat game."); // Add to config later
            return true;
        }

        // Default command (shows plugin info)
        sender.sendMessage("This server is running sChatGames v" + plugin.getDescription().getVersion());
        return true;
    }
}