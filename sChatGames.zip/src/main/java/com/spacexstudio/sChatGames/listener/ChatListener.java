package com.spacexstudio.sChatGames.listener;

import com.spacexstudio.sApi.SApi;
import com.spacexstudio.sApi.message.MessageReceiver;
import com.spacexstudio.sChatGames.SChatGames;
import com.spacexstudio.sChatGames.game.Game;
import com.spacexstudio.sChatGames.manager.GameManager;
import org.bukkit.Bukkit; // <-- THIS IS THE FIX
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

import java.text.DecimalFormat;

public class ChatListener implements Listener {

    private final SChatGames plugin;
    private final GameManager gameManager;
    private final DecimalFormat timeFormat = new DecimalFormat("#.##");

    public ChatListener(SChatGames plugin) {
        this.plugin = plugin;
        this.gameManager = plugin.getGameManager();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        if (!gameManager.isGameActive()) {
            return;
        }

        Player player = event.getPlayer();
        String message = event.getMessage();
        Game activeGame = gameManager.getActiveGame();

        if (activeGame.isCorrect(message)) {
            long timeTaken = System.currentTimeMillis() - activeGame.getStartTime();
            double timeInSeconds = timeTaken / 1000.0;

            // This must run on the main server thread!
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                // --- THIS IS THE FINAL, CORRECT FIX ---
                SApi.getInstance()
                        .message(plugin.getConfig(), "messages.game-win") // Get message from sChatGames's config
                        .with("{player}", player.getName())
                        .with("{answer}", activeGame.getAnswer())
                        .with("{time}", timeFormat.format(timeInSeconds))
                        .send(MessageReceiver.BROADCAST); // Broadcast it to everyone
                // --- END OF FIX ---

                // Give the rewards to the winning player.
                plugin.getRewardManager().giveRewards(player);

                gameManager.stopCurrentGame(false);
            });

            event.setCancelled(true);
        }
    }
}