package com.spacexstudio.sChatGames.scheduler;

import com.spacexstudio.sChatGames.SChatGames;
import com.spacexstudio.sChatGames.manager.GameManager;
import org.bukkit.Bukkit;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * A scheduler that automatically starts chat games at a configured interval.
 */
public class GameScheduler extends BukkitRunnable {

    private final SChatGames plugin;
    private final GameManager gameManager;

    public GameScheduler(SChatGames plugin) {
        this.plugin = plugin;
        this.gameManager = plugin.getGameManager();
    }

    @Override
    public void run() {
        // This method is called every time the scheduler runs.

        // 1. Check if a game is already active. If so, do nothing.
        if (gameManager.isGameActive()) {
            return;
        }

        // 2. Check if the minimum player count is met.
        int minimumPlayers = plugin.getConfig().getInt("settings.minimum-players", 1);
        if (Bukkit.getOnlinePlayers().size() < minimumPlayers) {
            return;
        }

        // All conditions are met, so start a new random game.
        gameManager.startRandomGame();
    }

    /**
     * Starts the scheduler task.
     */
    public void start() {
        long intervalTicks = plugin.getConfig().getLong("settings.game-interval", 300) * 20; // Convert seconds to ticks
        // Run the task asynchronously to avoid lagging the main server thread.
        this.runTaskTimerAsynchronously(plugin, 20L * 10, intervalTicks); // Start after 10 seconds, then repeat
        plugin.getLogger().info("GameScheduler has been started.");
    }
}