package com.spacexstudio.sChatGames;

import com.spacexstudio.sApi.SApi;
import com.spacexstudio.sApi.manager.MessageManager;
import com.spacexstudio.sChatGames.command.SChatGamesCommand;
import com.spacexstudio.sChatGames.listener.ChatListener;
import com.spacexstudio.sChatGames.manager.ConfigManager;
import com.spacexstudio.sChatGames.manager.GameManager;
import com.spacexstudio.sChatGames.manager.RewardManager;
import com.spacexstudio.sChatGames.scheduler.GameScheduler;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * The main class for the sChatGames plugin.
 * This plugin adds various fun and interactive games to the server chat.
 * It relies on sApi for shared utilities.
 *
 * @author sayam
 */
public final class SChatGames extends JavaPlugin {

    // Singleton instance for easy access from other classes within this plugin.
    private static SChatGames instance;

    // We will store an instance of the sApi MessageManager for easy use.
    private MessageManager messageManager;
    private GameManager gameManager;
    private RewardManager rewardManager;
    private ConfigManager configManager;

    @Override
    public void onEnable() {
        // Set the static instance of this plugin.
        instance = this;

        // --- API HOOK ---
        // It's a good practice to check if our dependency (sApi) is actually present.
        if (getServer().getPluginManager().getPlugin("sApi") == null) {
            getLogger().severe("sApi not found! This plugin requires sApi to function.");
            getLogger().severe("Disabling sChatGames...");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        // Get the MessageManager from our API.
        this.messageManager = SApi.getInstance().getMessageManager();
        // --- END API HOOK ---

        // Load the plugin's configuration file.
        saveDefaultConfig();

        // Print a nice startup message.
        messageManager.sendMessage(getServer().getConsoleSender(), "&a=======================================");
        messageManager.sendMessage(getServer().getConsoleSender(), "&b sChatGames is starting up!");
        messageManager.sendMessage(getServer().getConsoleSender(), "&b Version: " + getDescription().getVersion());

        // Initialize all the plugin's components.
        initializeManagers();
        registerCommands();
        startSchedulers();
        registerListeners();

        messageManager.sendMessage(getServer().getConsoleSender(), "&a sChatGames has been enabled successfully!");
        messageManager.sendMessage(getServer().getConsoleSender(), "&a=======================================");
    }

    @Override
    public void onDisable() {
        // Send a shutdown message.
        messageManager.sendMessage(getServer().getConsoleSender(), "&e=======================================");
        messageManager.sendMessage(getServer().getConsoleSender(), "&c sChatGames has been disabled.");
        messageManager.sendMessage(getServer().getConsoleSender(), "&e=======================================");
    }

    /**
     * Placeholder for initializing our game managers, schedulers, etc.
     */
    private void initializeManagers() {
        getLogger().info("Initializing managers...");
        this.configManager = new ConfigManager(this);
        this.gameManager = new GameManager(this);
        this.rewardManager = new RewardManager(this);
    }

    /**
     * Placeholder for registering plugin commands.
     */
    private void registerCommands() {
        getLogger().info("Registering commands...");
        getCommand("schatgames").setExecutor(new SChatGamesCommand(this));
    }

    /**
     * Placeholder for registering event listeners, like the chat listener.
     */
    private void registerListeners() {
        getLogger().info("Registering listeners...");
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
    }

    /**
     * Gets the singleton instance of this plugin.
     * @return The SChatGames instance.
     */
    public static SChatGames getInstance() {
        return instance;
    }

    /**
     * Gets the MessageManager instance from sApi.
     * @return The MessageManager instance.
     */
    public MessageManager getMessageManager() {
        return messageManager;
    }

    /**
     * Gets the GameManager instance for the plugin.
     * @return The GameManager instance.
     */
    public GameManager getGameManager() {
        return gameManager;
    }

    /**
     * Starts all plugin schedulers.
     */
    private void startSchedulers() {
        getLogger().info("Starting schedulers...");
        new GameScheduler(this).start();
    }

    /**
     * Gets the RewardManager instance for the plugin.
     * @return The RewardManager instance.
     */
    public RewardManager getRewardManager() {
        return rewardManager;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }
}